/etc/init.d/firmware-links.sh
firmware-links.sh 60
